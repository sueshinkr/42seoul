#include "cub3d.h"

int	keypress(int keycode, t_cub *cub)
{
	t_player *p = cub->player;

	if (keycode == 53)
		exit_game_with_map(5);
	else if (keycode == 13)
		move_up(cub->map, cub->player);
	else if (keycode == 1)
		move_down(cub->map, cub->player);
	else if (keycode == 0)
	{
		if (fabs(cub->player->dirX) > fabs(cub->player->dirY))
			move_left(cub->map, cub->player);
		else
			move_right(cub->map, cub->player);
	}
	else if (keycode == 2)
	{
		if (fabs(cub->player->dirX) > fabs(cub->player->dirY))
			move_right(cub->map, cub->player);
		else
			move_left(cub->map, cub->player);
	}
	
	if (keycode == 123)
	{
		camera_left(cub->player);
	}
	else if (keycode == 124)
	{
		camera_right(cub->player);
	}
	printf("pos(%f, %f)\n", p->posX, p->posY);
	printf("dir(%f, %f)\n", p->dirX, p->dirY);
	
	return (0);
}

// up 126 down 125
// left 123 right 124
// w 13 d 2 a 0 s 1 esc 53
